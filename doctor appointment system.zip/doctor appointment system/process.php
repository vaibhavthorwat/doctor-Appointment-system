<?php
// Set your MySQL database credentials
$servername = "localhost";
$username = "root";
$password = "vaibhav@1111";
$dbname = "niharika";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $doctor = $_POST['doctor'];
    $mode = $_POST['mode'];
    $location = $_POST['location'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    $sql = "INSERT INTO appointments (doctor, mode, location, date, time)
            VALUES ('$doctor', '$mode', '$location', '$date', '$time')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
