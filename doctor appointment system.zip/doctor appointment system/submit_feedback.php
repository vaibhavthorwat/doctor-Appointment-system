<?php
$servername = "localhost";
$username = "root";
$password = "vaibhav@1111";
$dbname = "niharika";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch form data
$doctor = $_POST['doctor-feedback'];
$rating = $_POST['rating'];
$comments = $_POST['comments'];

// Insert data into the database
$sql = "INSERT INTO feedback (doctor, rating, comments) VALUES ('$doctor', $rating, '$comments')";

if ($conn->query($sql) === TRUE) {
    echo "Feedback submitted successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
