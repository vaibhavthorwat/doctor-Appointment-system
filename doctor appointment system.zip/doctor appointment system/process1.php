<?php
// Database connection parameters
$servername = "localhost";  // Change this if your database is hosted elsewhere
$username = "root"; // Change this to your database username
$password = "vaibhav@1111"; // Change this to your database password
$database = "niharika"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["Name"];
    $age = $_POST["Age"];
    $gender = $_POST["Gender"];
    $phone = $_POST["Phone"];
    $email = $_POST["email"];
    $doctor = $_POST["doctor"];
    $mode = $_POST["mode"];
    $location = $_POST["location"];
    $date = $_POST["date"];
    $today = date("Y-m-d");

// Check if the selected date is not a previous date
if ($date >= $today) {
    // Proceed with further processing
    // Your code here
    echo "Selected date is valid.";
} else {
    // Handle the case where a previous date is selected
    echo "Error: Please select a date equal to or after today.";
}
    $comments = $_POST["comments"];
    $time = $_POST["time"];

    // Prepare and bind statement
    $stmt = $conn->prepare("INSERT INTO appointments (name, age, gender, phone, email, doctor, mode, location, date, comments, time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisssssssss", $name, $age, $gender, $phone, $email, $doctor, $mode, $location, $date, $comments, $time);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Appointment booked successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    header("Location: appointment.html");
    exit();
}

$conn->close();
?>
